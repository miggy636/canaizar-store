
Canaizar Stores — Website
Files:
- index.html    (main page)
- style.css     (styles)
- /images/      (place your logo and product images here; update img src paths in index.html)

Notes:
- Contact form uses FormSubmit to send messages to milliecanaiza@gmail.com.
- To add products, duplicate the product-card template (or edit the HTML) and place product images in the images/ folder.
- Footer credits: Created and Managed by Miguel — Admin of Canaizar Stores
